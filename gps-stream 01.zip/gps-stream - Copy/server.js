// server.js
//
// Reads NMEA sentences from a USB GPS receiver on a serial port,
// parses RMC fixes, and pushes them to the browser over Socket.IO.
//
// Usage:
//   node server.js                      → reads from real serial port
//   MOCK=1 node server.js               → emits synthetic fixes (no hardware needed)
//   PORT_PATH=COM4 BAUD=9600 node server.js
//
// Override port/baud via env vars or edit the defaults below.

const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const SERIAL_PATH = process.env.PORT_PATH || 'COM5';
const BAUD_RATE = parseInt(process.env.BAUD || '9600', 10);
const HTTP_PORT = parseInt(process.env.HTTP_PORT || '3000', 10);
const USE_MOCK = process.env.MOCK === '1';

// --- NMEA helpers ----------------------------------------------------------

function checksumOk(sentence) {
  const m = sentence.match(/^\$(.*)\*([0-9A-F]{2})$/i);
  if (!m) return false;
  let c = 0;
  for (const ch of m[1]) c ^= ch.charCodeAt(0);
  return c === parseInt(m[2], 16);
}

function toDeg(raw, hemi) {
  if (!raw) return null;
  const dot = raw.indexOf('.');
  const deg = parseInt(raw.slice(0, dot - 2), 10);
  const min = parseFloat(raw.slice(dot - 2));
  let v = deg + min / 60;
  if (hemi === 'S' || hemi === 'W') v = -v;
  return v;
}

function parseRMC(s) {
  const f = s.split(',');
  if (f[2] !== 'A') return null; // 'V' = void / no fix
  return {
    lat: toDeg(f[3], f[4]),
    lon: toDeg(f[5], f[6]),
    speedKn: parseFloat(f[7]) || 0,
    timeUTC: f[1],
  };
}

function handleLine(line) {
  if (!checksumOk(line)) return;
  if (line.startsWith('$GPRMC') || line.startsWith('$GNRMC')) {
    const fix = parseRMC(line);
    if (fix) io.emit('fix', fix);
  }
}

// --- Serial port with reconnect -------------------------------------------

function startSerial() {
  const { SerialPort } = require('serialport');
  const { ReadlineParser } = require('@serialport/parser-readline');

  let port = null;
  let reconnectDelay = 1000;
  const MAX_RECONNECT_DELAY = 30000;

  function openPort() {
    console.log(`[serial] opening ${SERIAL_PATH} @ ${BAUD_RATE}...`);

    port = new SerialPort({
      path: SERIAL_PATH,
      baudRate: BAUD_RATE,
      autoOpen: false,
      rtscts: false,
      xon: false,
      xoff: false,
      xany: false,
    });

    const parser = port.pipe(new ReadlineParser({ delimiter: '\r\n' }));
    parser.on('data', (data) => {
      console.log('[raw]', data); // Debug: show all incoming data
      handleLine(data);
    });

    // Also try reading raw without delimiter
    port.on('data', (data) => {
      const str = data.toString();
      console.log('[bytes]', str);
      // Try to parse any line-like structures
      str.split('\n').forEach(line => {
        if (line.trim()) {
          console.log('[line]', line.trim());
          handleLine(line.trim());
        }
      });
    });

    port.on('open', () => {
      console.log('[serial] open');
      reconnectDelay = 1000;
      io.emit('serial-status', { connected: true });
    });

    port.on('close', () => {
      console.warn('[serial] closed');
      io.emit('serial-status', { connected: false });
      scheduleReconnect();
    });

    port.on('error', (err) => {
      console.error('[serial] error:', err.message);
      if (port && port.isOpen) {
        port.close(() => {});
      } else {
        scheduleReconnect();
      }
    });

    port.open((err) => {
      if (err) {
        console.error('[serial] open failed:', err.message);
        scheduleReconnect();
      }
    });
  }

  function scheduleReconnect() {
    console.log(`[serial] reconnect in ${reconnectDelay} ms`);
    setTimeout(openPort, reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 2, MAX_RECONNECT_DELAY);
  }

  openPort();
}

// --- Mock mode (no hardware) ----------------------------------------------
//
// Walks a synthetic position around a starting point at ~10 Hz so you can
// verify the stack end-to-end before plugging anything in.

function startMock() {
  console.log('[mock] emitting synthetic fixes at 10 Hz');
  let lat = 45.815; // Zagreb-ish, change freely
  let lon = 15.9819;
  let bearing = 0;

  io.on('connection', (socket) => {
    socket.emit('serial-status', { connected: true });
  });

  setInterval(() => {
    bearing += (Math.random() - 0.5) * 0.2;
    const step = 0.00002;
    lat += Math.cos(bearing) * step;
    lon += Math.sin(bearing) * step;

    const now = new Date();
    const hh = String(now.getUTCHours()).padStart(2, '0');
    const mm = String(now.getUTCMinutes()).padStart(2, '0');
    const ss = String(now.getUTCSeconds()).padStart(2, '0');
    const ms = String(now.getUTCMilliseconds()).padStart(3, '0');

    io.emit('fix', {
      lat,
      lon,
      speedKn: 2 + Math.random(),
      timeUTC: `${hh}${mm}${ss}.${ms}`,
    });
  }, 100);
}

// --- Boot ------------------------------------------------------------------

if (USE_MOCK) {
  startMock();
} else {
  try {
    startSerial();
  } catch (err) {
    console.error('Failed to initialize serial port. Is the `serialport` package installed?');
    console.error('Tip: run `npm install`, or start with MOCK=1 to test without hardware.');
    console.error(err.message);
    process.exit(1);
  }
}

server.listen(HTTP_PORT, () => {
  console.log(`http://localhost:${HTTP_PORT}`);
});
