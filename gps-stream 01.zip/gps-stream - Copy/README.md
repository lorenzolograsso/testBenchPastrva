# gps-stream

Streams NMEA fixes from a USB GPS receiver to the browser over a WebSocket and displays the live coordinates centered on screen.

## Run

```bash
npm install
npm start
```

Open http://localhost:3000

## No hardware? Try mock mode

Useful to verify the stack end-to-end before plugging anything in. Emits synthetic fixes at 10 Hz that drift around a starting point.

```bash
# macOS / Linux
MOCK=1 npm start

# Windows (PowerShell)
$env:MOCK="1"; npm start

# Windows (cmd)
set MOCK=1 && npm start
```

## Configure the serial port

Defaults are `COM3` at `115200` baud. Override via env vars:

```bash
PORT_PATH=COM4 BAUD=9600 npm start
```

If you don't know your port: open Device Manager → Ports (COM & LPT), or run a quick listing:

```bash
node -e "require('serialport').SerialPort.list().then(p => console.log(p))"
```

## What it shows

The browser displays latitude and longitude in WGS-84 large and centered, with speed (knots), UTC time, current update rate (Hz), and total fix count below. A status pill in the top right indicates whether the GPS is streaming or disconnected.

## Notes

- Receiver must be emitting `$GPRMC` or `$GNRMC` sentences. Most multi-GNSS units do this by default.
- The server validates NMEA checksums and silently drops malformed lines (expect a few during startup as it syncs to the stream mid-sentence).
- The serial port auto-reconnects with exponential backoff (1s → 30s) if the device is unplugged or hasn't been plugged in yet.
- If your receiver defaults to 1 Hz / 9600 baud, you'll need to send a configuration sentence (`$PMTK` for MediaTek-based, `$PUBX` / UBX binary for u-blox) before it streams at 18 Hz. That's receiver-specific and not handled here.
